This is the first official release of the R3X Virtual Machine for Linux 64-bit. (GL)

Please understand that the project is still in beta, and there may have been bugs that might have been overloooked  by me. This is an UNSTABLE release, I'm only releasing this for those who just want try it out for themselves.

With that aside, the Virtual Machine and the toolchain are very much functional. Although, the programs may seem quite crude, in their output, they are pretty usable.

REQUIREMENTS

A Linux distro (preferably Ubuntu, since this was compiled on Ubuntu 14.04) and a 64-bit x86 CPU. Since this release is a full-blown release, you would need OpenGL support (or similar) as well.

Of course, I'm working on non-GL releases, and releases for other platforms as well.

SETTING UP

The tar file for this release contains four directories, "rxvm", "rcc" , "ircbot" and "lib". The "rxvm" directory contains the "init" program, the font file, the R3X standard library ("rstdlib.so"), and the VM executable "rxvm".

You can put this directory anywhere, since the VM uses "readlink(2)" to get it's executable path, the program is relocatable.

After you have chosen your VM's directory, simply export it to your $PATH in your .bashrc as:

export PATH=$PATH:"<directory of your vm>"


The "_rcc_" directory contains the VM toolchain. This includes:
* t++ - The compiler frontend
* tbc - The compiler backend
* readrex - Executable information dumping tool
* rexdump - Disassembler
* cgen - CRC32 Checksum Generation tool
* fasm - Flat Assembler (used as backend)
* /libR3X/ - Required architecture assembly files for FASM.
* /include/ - Contains include headers for rstdlib.

Once you have copied the files to the their destination, you have to add two new environment variables, since the compiler uses a different mechanism than the VM. (Note that all of those files and directories must be in the same location!)


# Export the compiler path as RX_PREFIX
export RX_PREFIX="<directory of your compiler>" 
# Export the standard header include directory as STDLIB_R3X
export STDLIB_R3X="<directory of your compiler>/include"
# Now add RX_PREFIX to PATH so that we can execute the compiler directly from the shell, anywhere
export PATH=$PATH:$RX_PREFIX

Now you're done!

The "ircbot" directory contains an example of a simple IRC bot, which sends message to the #rxvm channel on irc.freenode.net, and then receives messages and prints them to screen. Compile instructions are given in the comments.

The "lib" directory contains binaries for libraries required to build a native library (a dynamic library), which can be used by R3X programs. It also contains an "include" directory which has the header files for the libraries.

GOING FURTHER

You can refer to the docs directory, (in the repository) for the technical details of the VM and the programming language. Have fun!

LICENSE

R3X is liencsed under the New BSD License.
